-- Adminer 4.7.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `app_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `app_db`;

DROP TABLE IF EXISTS `t_authors`;
CREATE TABLE `t_authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `t_authors` (`id`, `name`) VALUES
(1,	'Victor Hugo'),
(2,	' Bernard Werber');

DROP TABLE IF EXISTS `t_books`;
CREATE TABLE `t_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `summary` text NOT NULL,
  `img` tinytext,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `author_id` int(11) NOT NULL,
  `genre_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `grade_id` (`grade_id`),
  KEY `genre_id` (`genre_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `t_books_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `t_authors` (`id`),
  CONSTRAINT `t_books_ibfk_2` FOREIGN KEY (`grade_id`) REFERENCES `t_grades` (`id`),
  CONSTRAINT `t_books_ibfk_4` FOREIGN KEY (`genre_id`) REFERENCES `t_genres` (`id`),
  CONSTRAINT `t_books_ibfk_6` FOREIGN KEY (`user_id`) REFERENCES `t_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `t_books` (`id`, `name`, `summary`, `img`, `date`, `author_id`, `genre_id`, `grade_id`, `user_id`) VALUES
(2,	'Le dernier jour d\'un condamné',	'Ce roman se présente comme le journal d\'un condamné à mort écrit durant les vingt-quatre dernières heures de son existence dans lequel il raconte ce qu\'il a vécu depuis le début de son procès jusqu\'au moment de son exécution, soit environ six semaines de sa vie. Ce récit, long monologue intérieur, est entrecoupé de réflexions angoissées et de souvenirs de son autre vie, la « vie d’avant ». Le lecteur ne connaît ni le nom de cet homme, ni ce qu\'il a fait pour être condamné, mis à part la phrase : « moi, misérable qui ai commis un véritable crime, qui ai versé du sang ! ». L’œuvre se présente comme un témoignage brut, à la fois sur l’angoisse du condamné à mort et ses dernières pensées, les souffrances quotidiennes morales et physiques qu\'il subit et sur les conditions de vie des prisonniers, par exemple dans la scène du ferrage des forçats. Il exprime ses sentiments sur sa vie antérieure et ses états d’âme.\r\n\r\nIl se fera exécuter sous la clameur du peuple qui voit sa mort comme un spectacle.',	'https://media.cultura.com/media/catalog/product/cache/1/image/1000x1000/9df78eab33525d08d6e5fb8d27136e95/l/e/le-dernier-jour-d-un-condamne-9782266161107_0.jpg',	'2019-09-03 14:32:17',	1,	1,	1,	1),
(3,	'Les fourmis',	'Le temps que vous lisiez ces lignes, sept cents millions de fourmis seront nées sur la planète. Sept cents millions d\'individus dans une communauté estimée à un milliard de milliards, et qui a ses villes, sa hiérarchie, ses colonies, son langage, sa production industrielle, ses esclaves, ses mercenaires... Ses armes aussi. Terriblement destructrices.Lorsqu\'il entre dans la cave de la maison léguée par un vieil oncle entomologiste, Jonathan Wells est loin de se douter qu\'il va à leur rencontre.A sa suite, nous allons découvrir le monde fabuleusement riche, monstrueux et fascinant de ces \"infraterrestres\", au fil d\'un thriller unique en son genre, où le suspense et l\'horreur reposent à chaque page sur les données scientifiques les plus rigoureuses.Voici pour la première fois un roman dont les héros sont des... fourmis ',	'https://media.senscritique.com/media/000000144540/source_big/Les_Fourmis.jpg',	'2019-09-04 10:30:39',	2,	2,	1,	2);

DROP TABLE IF EXISTS `t_genres`;
CREATE TABLE `t_genres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `t_genres` (`id`, `name`) VALUES
(1,	'Classique'),
(2,	'philosophie fiction');

DROP TABLE IF EXISTS `t_grades`;
CREATE TABLE `t_grades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `grade` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `t_grades` (`id`, `name`, `grade`) VALUES
(1,	'Gold',	2),
(2,	'Diamant',	1),
(3,	'Platine',	3),
(4,	'Argent',	4),
(5,	'Bronze',	5);

DROP TABLE IF EXISTS `t_users`;
CREATE TABLE `t_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `role` tinyint(2) NOT NULL DEFAULT '0',
  `img` text,
  `about` mediumtext,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `t_users` (`id`, `name`, `role`, `img`, `about`, `password`) VALUES
(1,	'Admin',	1,	'https://www.gaido.fr/wp-content/uploads/2016/07/avatar-375-456327.png',	'C\'est moi l\'admin !',	'0000'),
(2,	'lulu',	0,	'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTR8HdpHq47faAqRNVmIFXgpGxh7PwjULHUtouQRm0dtljiIyIs',	NULL,	'0000');

-- 2019-09-05 15:19:39
